# import numpy as np
import pandas as pd
# import openpyxl

# try except here to check if it's a csv of excel file
while True:
    file = input('Filename of dataset: ')
    try:
        assert(file[-3:] == "csv" or file[-4:] == "xlsx")
        break
    except AssertionError:
        print("This is not a valid file. Input must be .xlsx or .csv file. Try again!")      
# read in data

if file[-3:] == "csv":
    # read in as csv
    df = pd.read_csv(file)
    df = df.to_numpy()
elif file[-4:] == "xlsx":
    # read in as excel file
    dfExcel = pd.read_excel (file, header=None)
    df = dfExcel.to_numpy()

print(df)